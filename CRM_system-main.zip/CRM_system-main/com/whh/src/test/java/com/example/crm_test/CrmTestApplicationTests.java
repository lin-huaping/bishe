package com.example.crm_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
