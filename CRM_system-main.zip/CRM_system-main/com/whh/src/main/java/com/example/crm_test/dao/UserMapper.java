package com.example.crm_test.dao;

public interface UserMapper {

//    public User querytest(String username);
}
