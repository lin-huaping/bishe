package com.example.crm_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrmTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(CrmTestApplication.class, args);
    }

}
