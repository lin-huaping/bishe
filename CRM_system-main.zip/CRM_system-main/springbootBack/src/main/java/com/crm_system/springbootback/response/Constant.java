package com.crm_system.springbootback.response;

public class Constant {
    /**
     * 数据插入成功返回的统一消息
     */
    public static final String ADD_SUCCESS = "数据添加成功";

    public static final String ADD_FAIL = "数据添加失败";
    /**
     *
     */
    public static final String LOGIN_SUCCESS = "登录成功";
}
