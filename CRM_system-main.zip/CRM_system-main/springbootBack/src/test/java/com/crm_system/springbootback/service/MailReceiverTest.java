//package com.crm_system.springbootback.service;
//
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//@RunWith(SpringRunner.class)
//@SpringBootTest
//class MailReceiverTest {
//    @Autowired
//    MailReceiver mailReceiver;
//    @Test
//    public void sendSimpleMail() {
//        mailReceiver.sendSimpleMail("1452588824@qq.com", "2466921236@qq.com", "1452588824@qq.com", "wwh", "wwh");
//    }
//}