package com.crm_system.springbootback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBackApplicationTests {

    @Test
    void contextLoads() {
    }

}
