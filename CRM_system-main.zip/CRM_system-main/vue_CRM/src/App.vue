<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  /*font-family: 'Avenir', Helvetica, Arial, sans-serif;*/
  /*-webkit-font-smoothing: antialiased;*/
  /*-moz-osx-font-smoothing: grayscale;*/
  /*text-align: center;*/
  /*color: #2c3e50;*/
  /*margin: -20px;*/
  /* width: 100%; */
  padding-bottom: 10px;
}
html,
body {
  margin: 0;
  padding: 0;
  /* height: 100%; */

  background-color: #b8d6de;
}
</style>
