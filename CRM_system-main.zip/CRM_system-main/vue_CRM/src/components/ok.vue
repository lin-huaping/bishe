<template>
  <div style="width:auto;margin:auto;height:auto;text-align:center">更新成功</div>
</template>

<script>
export default {

}
</script>

<style>
</style>