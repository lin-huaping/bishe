<template>
  <div style="display:flex;flex-direction:column;justify-content:center;align-items:center">
    <img style="width:400px"
         src="../assets/信息.png">
    <h1>欢迎登录！</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>
</style>